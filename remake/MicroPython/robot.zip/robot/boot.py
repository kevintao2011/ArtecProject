# boot.py -- run on boot-up
print("Running boot.py")

print("imported pyatcrobo2")

print("imported pystubit")

print("Finished boot script")


