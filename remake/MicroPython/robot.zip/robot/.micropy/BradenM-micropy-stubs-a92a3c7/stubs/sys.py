"""
Module: 'sys' on esp32 1.11.0
"""
# MCU: (sysname='esp32', nodename='esp32', release='1.11.0', version='v1.11-132-gc24d81119 on 2019-07-08', machine='ESP32 module with ESP32')
# Stubber: 1.2.0
argv = None
byteorder = 'little'
def exit():
    pass

implementation = None
maxsize = 2147483647
modules = None
path = None
platform = 'esp32'
def print_exception():
    pass

stderr = None
stdin = None
stdout = None
version = '3.4.0'
version_info = None
