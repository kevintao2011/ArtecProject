"""
Module: 'io' on esp32 1.11.0
"""
# MCU: (sysname='esp32', nodename='esp32', release='1.11.0', version='v1.11-132-gc24d81119 on 2019-07-08', machine='ESP32 module with ESP32')
# Stubber: 1.2.0

class BufferedWriter:
    ''
    def flush():
        pass

    def write():
        pass


class BytesIO:
    ''
    def close():
        pass

    def flush():
        pass

    def getvalue():
        pass

    def read():
        pass

    def readinto():
        pass

    def readline():
        pass

    def seek():
        pass

    def write():
        pass


class FileIO:
    ''
    def close():
        pass

    def flush():
        pass

    def read():
        pass

    def readinto():
        pass

    def readline():
        pass

    def readlines():
        pass

    def seek():
        pass

    def tell():
        pass

    def write():
        pass


class IOBase:
    ''

class StringIO:
    ''
    def close():
        pass

    def flush():
        pass

    def getvalue():
        pass

    def read():
        pass

    def readinto():
        pass

    def readline():
        pass

    def seek():
        pass

    def write():
        pass


class TextIOWrapper:
    ''
    def close():
        pass

    def flush():
        pass

    def read():
        pass

    def readinto():
        pass

    def readline():
        pass

    def readlines():
        pass

    def seek():
        pass

    def tell():
        pass

    def write():
        pass

def open():
    pass

