"""
Module: 'ntptime' on esp32 1.11.0
"""
# MCU: (sysname='esp32', nodename='esp32', release='1.11.0', version='v1.11-132-gc24d81119 on 2019-07-08', machine='ESP32 module with ESP32')
# Stubber: 1.2.0
NTP_DELTA = 3155673600
host = 'pool.ntp.org'
def settime():
    pass

socket = None
struct = None
def time():
    pass

