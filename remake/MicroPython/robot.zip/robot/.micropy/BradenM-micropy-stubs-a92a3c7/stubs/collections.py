"""
Module: 'collections' on esp32 1.11.0
"""
# MCU: (sysname='esp32', nodename='esp32', release='1.11.0', version='v1.11-132-gc24d81119 on 2019-07-08', machine='ESP32 module with ESP32')
# Stubber: 1.2.0

class OrderedDict:
    ''
    def clear():
        pass

    def copy():
        pass

    def fromkeys():
        pass

    def get():
        pass

    def items():
        pass

    def keys():
        pass

    def pop():
        pass

    def popitem():
        pass

    def setdefault():
        pass

    def update():
        pass

    def values():
        pass


class deque:
    ''
    def append():
        pass

    def popleft():
        pass

def namedtuple():
    pass

