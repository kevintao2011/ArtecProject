"""
Module: 'upip_utarfile' on esp32 1.11.0
"""
# MCU: (sysname='esp32', nodename='esp32', release='1.11.0', version='v1.11-132-gc24d81119 on 2019-07-08', machine='ESP32 module with ESP32')
# Stubber: 1.2.0
DIRTYPE = 'dir'

class FileSection:
    ''
    def read():
        pass

    def readinto():
        pass

    def skip():
        pass

REGTYPE = 'file'
TAR_HEADER = None

class TarFile:
    ''
    def extractfile():
        pass

    def next():
        pass


class TarInfo:
    ''
def roundup():
    pass

uctypes = None
