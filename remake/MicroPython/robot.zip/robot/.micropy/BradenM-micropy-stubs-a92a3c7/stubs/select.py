"""
Module: 'select' on esp32 1.11.0
"""
# MCU: (sysname='esp32', nodename='esp32', release='1.11.0', version='v1.11-132-gc24d81119 on 2019-07-08', machine='ESP32 module with ESP32')
# Stubber: 1.2.0
POLLERR = 8
POLLHUP = 16
POLLIN = 1
POLLOUT = 4
def poll():
    pass

def select():
    pass

