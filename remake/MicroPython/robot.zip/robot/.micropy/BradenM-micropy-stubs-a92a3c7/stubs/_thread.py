"""
Module: '_thread' on esp32 1.11.0
"""
# MCU: (sysname='esp32', nodename='esp32', release='1.11.0', version='v1.11-132-gc24d81119 on 2019-07-08', machine='ESP32 module with ESP32')
# Stubber: 1.2.0

class LockType:
    ''
    def acquire():
        pass

    def locked():
        pass

    def release():
        pass

def allocate_lock():
    pass

def exit():
    pass

def get_ident():
    pass

def stack_size():
    pass

def start_new_thread():
    pass

