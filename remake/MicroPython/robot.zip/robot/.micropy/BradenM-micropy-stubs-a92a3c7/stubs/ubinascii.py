"""
Module: 'ubinascii' on esp32 1.11.0
"""
# MCU: (sysname='esp32', nodename='esp32', release='1.11.0', version='v1.11-132-gc24d81119 on 2019-07-08', machine='ESP32 module with ESP32')
# Stubber: 1.2.0
def a2b_base64():
    pass

def b2a_base64():
    pass

def crc32():
    pass

def hexlify():
    pass

def unhexlify():
    pass

