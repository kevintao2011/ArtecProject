"""
Module: 'micropython' on esp32 1.11.0
"""
# MCU: (sysname='esp32', nodename='esp32', release='1.11.0', version='v1.11-132-gc24d81119 on 2019-07-08', machine='ESP32 module with ESP32')
# Stubber: 1.2.0
def alloc_emergency_exception_buf():
    pass

def const():
    pass

def heap_lock():
    pass

def heap_unlock():
    pass

def kbd_intr():
    pass

def mem_info():
    pass

def opt_level():
    pass

def qstr_info():
    pass

def schedule():
    pass

def stack_use():
    pass

