"""
Module: 'time' on esp32 1.11.0
"""
# MCU: (sysname='esp32', nodename='esp32', release='1.11.0', version='v1.11-132-gc24d81119 on 2019-07-08', machine='ESP32 module with ESP32')
# Stubber: 1.2.0
def localtime():
    pass

def mktime():
    pass

def sleep():
    pass

def sleep_ms():
    pass

def sleep_us():
    pass

def ticks_add():
    pass

def ticks_cpu():
    pass

def ticks_diff():
    pass

def ticks_ms():
    pass

def ticks_us():
    pass

def time():
    pass

