# main.py
print('-------start main script-------')



# compass = StuduinoBitCompass ()
# compassReading = compass.heading()
# if(button_b.is_pressed):
#     compass.calibrate()

#-----------------------------IMPORTS----------------------------#
from pystubit.image import StuduinoBitImage
from pystubit.sensor import StuduinoBitCompass
from pystubit.button import StuduinoBitButton
from pystubit.dsply import StuduinoBitDisplay

from pyatcrobo2.parts import DCMotor

import time
import _thread
import json
import socket
import network
import os
import machine
import pyatcrobo2

#-----------------------------IMPORTS------------------------------------------#

# ----------------------------CONSTANTS-----------------------#
HEADER = 64
PORT = 6000
FORMAT = "utf-8"
DISCONNECT_MESSAGE = "!DISCONNECT"
# SERVER = "192.168.1.17"
# SERVER = "10.22.1.126"
SERVER = "192.168.31.36" #Xiaomi
# Server = "127.0.0.1"
#SERVER = "192.168.1.83"  # home wifi

ADDR = (SERVER, PORT)
#ADDR = ('192.168.1.83', 6000)

# ----------------------------CONSTANTS-----------------------#

#-----------------------------ARTEC HARDWARE CONFIG----------------------------#
L = DCMotor('M1')
R = DCMotor('M2')
# L.power(50)
# R.power(50)
display = StuduinoBitDisplay()
display.on()

button_a = StuduinoBitButton('A')
button_b = StuduinoBitButton('B')
#-----------------------------ARTEC HARDWARE CONFIG----------------------------#



#-----------------------------DEFIND CLASS------------------------------#
class msg:
    def __init__(self, cmd, data):
        self.cmd = cmd
        self.data = data
        
#-----------------------------DEFIND CLASS------------------------------#



# -------------------------------CMD Action-------------------#
def recvdata(socket: socket):
    """
    Description:
        handle raw byte income, reuturn lib.msg object
    Args:
        socket (socket): _description_

    Returns:
        Union[msg,bool]: Return in format of {'cmd':str,'data',str}
    """
    msg_length = socket.recv(HEADER).decode(FORMAT)
    #print("read msg_length: ",msg_length)

    if msg_length:
        message = socket.recv(int(msg_length)).decode(FORMAT)
        #data = json.loads(message)
        print('message',message)
        return message
    else:
        #print("Fail to recv data")
        return False


def updateCMD(s: socket,command):
    print("Started thread")
    
    while True:
        print("waitng msg...")
        data = recvdata(s)
        if command != '':
            print(data)
        


def executeCMD(received_action,command):
    
    if received_action == "green":
        ok_logo()
        received_action = "Keep Standby"
        command = ''
    elif received_action == "red":
        print("Execute red")
        redCross_logo()
        received_action = "Keep Standby"
        command = ''
    # elif received_action == "fw":
    #     dcmotor.rotate(m2="ccw")
    #     dcmotor.set_power(m1=50)
    #     dcmotor.rotate(m1="ccw")
    #     dcmotor.set_power(m2=50)
    # elif received_action == "bk":
    #     dcmotor.rotate(m2="cw")
    #     dcmotor.set_power(m1=50)
    #     dcmotor.rotate(m1="cw")
    #     dcmotor.set_power(m2=50)
    # elif received_action == "cw":
    #     dcmotor.rotate(m2="cw")
    #     dcmotor.set_power(m1=30)
    #     dcmotor.rotate(m1="ccw")
    #     dcmotor.set_power(m2=30)
    # elif received_action == "ccw":
    #     dcmotor.rotate(m2="ccw")
    #     dcmotor.set_power(m1=30)
    #     dcmotor.rotate(m1="cw")
    #     dcmotor.set_power(m2=30)
    # elif received_action == "stop":
    #     dcmotor.stop("brake", "brake")
    else:
        print("No registered command matched")

# -------------------------------CMD Action-------------------#

# ------------------------WIFI & SERVER connection-------------------#

def do_connect():
    
    wlan = network.WLAN(network.STA_IF)
    wlan.active(True)
    if not wlan.isconnected():
        print('connecting to network...')
        wlan.connect('NETGEAR76', 'quiettulip014')
        while not wlan.isconnected():
            pass
    print('network config:', wlan.ifconfig())
    
def connectServer()->socket.socket:
    ADDR = ('192.168.1.83', 6000) 
    client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    print('try connect to server')
    client.connect(ADDR)
    print('connected to server')
    send('3',client)
    
    print('sent handshake to server')
    return client
    
def recvdata(socket: socket.socket):
    """
    Description:
        handle raw byte income, reuturn lib.msg object
    Args:
        socket (socket): _description_

    Returns:
        Union[msg,bool]: Return in format of {'cmd':str,'data',str}
    """
    
    msg_length = socket.recv(HEADER).decode(FORMAT)
    #print("read msg_length: ",msg_length)

    if msg_length:
        message = socket.recv(int(msg_length)).decode(FORMAT)
        #data = json.loads(message)
        print('message',message)
        return message
        #try:
            # print(fnlogg(),"read msg: ",message)

            # print(fnlogg(),data)
            # print(fnlogg(),'Receiving cmd:',data['cmd'])
            # print(logg(),'Receiving data:',data['data'])
            # print(fnlogg(),"Type",type(data))
            #data = msg(data["cmd"], data["data"])
        #    return message
        #except:
            #print("Fail to recv data")
            #return False
    else:
        #print("Fail to recv data")
        return False
    

def send(msg,socket:socket):
    message = msg.encode(FORMAT)
    msg_length = len(message)
    send_length = str(msg_length).encode(FORMAT)
    send_length += b" " * (HEADER - len(send_length))

    socket.send(send_length)
    socket.send(message)


# ------------------------WIFI & SERVER connection-------------------#
    


#
def ok_logo():
    StuduinoBitImage(
        [
            (0, 0, 0x001F00),
            (1, 0, 0x001F00),
            (2, 0, 0x001F00),
            (3, 0, 0x001F00),
            (4, 0, 0x001F00),
            (0, 1, 0x001F00),
            (4, 1, 0x001F00),
            (0, 2, 0x001F00),
            (4, 2, 0x001F00),
            (0, 3, 0x001F00),
            (4, 3, 0x001F00),
            (0, 4, 0x001F00),
            (1, 4, 0x001F00),
            (2, 4, 0x001F00),
            (3, 4, 0x001F00),
            (4, 4, 0x001F00),
        ]
    )
def redCross_logo():
    StuduinoBitImage(
        [
            (0, 0, 0x1F0000),
            (4, 0, 0x1F0000),
            (1, 1, 0x1F0000),
            (3, 1, 0x1F0000),
            (2, 2, 0x1F0000),
            (1, 3, 0x1F0000),
            (3, 3, 0x1F0000),
            (0, 4, 0x1F0000),
            (4, 4, 0x1F0000),
        ]
    )
    
#------------------------THREAD-------------------------#

    
# -----------------------main------------------------
startTime = time.time()

print("--- %s seconds ---" % (time.time() - startTime))
client = do_connect()
connectServer()
global command
command = ''
_thread.start_new_thread(updateCMD, (connectServer(),command))

while True:
    try:
        executeCMD(command)
    except:
        pass




    
