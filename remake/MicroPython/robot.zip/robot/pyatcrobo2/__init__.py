from . import body
from .parts import DCMotor
from .parts import Servomotor
from .parts import Buzzer
from .parts import LED
from .parts import IRPhotoReflector
from .parts import LightSensor
from .parts import SoundSensor
from .parts import TouchSensor
from .parts import Temperature
from .parts import UltrasonicSensor
from .parts import Accelerometer
# from parts import Gyro

