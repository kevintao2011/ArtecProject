# boot.py -- run on boot-up
print("Running boot.py")
print("HI")
import pyatcrobo2
print("imported pyatcrobo2")
import pystubit
print("imported pystubit")

print("Finished boot script")


