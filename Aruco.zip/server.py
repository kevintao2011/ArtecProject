
import socket 
import threading
import json
import time
from unittest import case
import _thread

HEADER = 64

devicelist = []
# SERVER = "192.168.1.8"
# SERVER = "192.168.1.17"
SERVER = "192.168.1.40"
PORT = 5050
ADDR = (SERVER, PORT)
FORMAT = 'utf-8'
DISCONNECT_MESSAGE = "!DISCONNECT"
CLI_cmd = ""
lock = threading.Lock()

class device:
    def __init__(self, addr ,connObj):
        self.addr = addr  # 
        self.index = len(devicelist)   # 
        self.connObj = connObj 
        self.nextAction = ""
        print("Host :added device")
        print("Host :device ip is", self.addr)
        print("Host :device index is",self.index)
        
class msg:
    def __init__(self,cmd,data):
        self.cmd = cmd
        self.data = data

def getConnected():
    return devicelist

def terminal_thread(robot,command):
    time.sleep(3)
    cmdmsg = msg(robot.addr,robot.connObj)
    command.split(",")
    robot = devicelist[robot.index]
    #robot.connObj.send("wtauohiweduijwh djahjkawhdjkaw nkdywcwqycadca.".encode(FORMAT)) #can actively send  cmd


server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.bind(ADDR)

def convertJson(text):
    print('Function: convertJson')
    mymsg = json.dumps(msg("Host",text).__dict__) #_dict_ send in plaint json text
    return mymsg

def handle_client(conn, addr): #Thread function
    global CLI_cmd # access the global CLI_cmd variable
    # print(f"[NEW CONNECTION] {addr} connected.")
    duplicated = False
    currentDevice= any
    for devices in devicelist: #Check if new connection
        print("Host : Old addr:",devices.addr," New addr:",addr)
        if devices.addr[0]==addr[0]:
            print("Host : device Duplicated")
            devices.addr = addr
            devices.connObj = conn
            print("Host : Updated socket") #reconnection will chg socket and the cnnection
            duplicated = True
            currentDevice= devices
            
    if(not duplicated): #Check if it is new device
        print("addr: " , addr)
        devicelist.append(device(addr,conn))
        currentDevice= devicelist[len(devicelist)-1]
        # print("registered new device:," )
        # print("IpAddress =" ,addr)
        # print("Index",devicelist[len(devicelist)-1])
        
    getConnected() # show connected device
    print("currentDevice",currentDevice.index)
    connected = True
    while connected: #close loop for waiting message
        #lock.acquire()
        local_CLI_cmd = CLI_cmd
        #print(currentDevice.index,"CLI_cmd:",local_CLI_cmd) #duplicate at first
        # print("waiting new msg...")
        msg_length = conn.recv(HEADER).decode(FORMAT)
        # print("Received new msg...")
        
        if msg_length:
            print()
            msg_length = int(msg_length)
            
            msg = conn.recv(msg_length).decode(FORMAT)
            _thread.start_new_thread(terminal_thread,(currentDevice,"connected"))
            if msg == DISCONNECT_MESSAGE: #close connection
                connected = False
                
            #print("All Msg: "f"{msg}") #print the msg
            
            # check sending source
            elif(msg == "New Connection: Connect form studuino"): 
                for x in range (len(devicelist)):
                    print("Index: ",devicelist[x].index," IP:",devicelist[x].addr)
            
            elif (msg == "From CLI"):
                conn.send(("Msg received:"f"{msg}".encode(FORMAT)))
            elif (msg == "From Object detection"):
                conn.send(("Msg received:"f"{msg}".encode(FORMAT)))    
            
            # check received command
            elif msg[0]=='{':
                print("Host :receiveing JSON")
                data = json.loads(msg)
                
                print('Receiving cmd:',data['cmd'])
                print('Receiving data:',data['data'])
                print("Type",type(data))
                # for studuino response 
                if(data['cmd']=="Request"):
                    print(currentDevice.index,"From device: Requesting")
                    # if(currentDevice.nextAction==""):
                    if(local_CLI_cmd==""):
                        conn.send(("Keep Standby".encode(FORMAT)))
                    else: #if(currentDevice.nextAction==data['data']):
                        conn.send((local_CLI_cmd.encode(FORMAT)))
                # for CLI
                elif(data['cmd']=="Host"):
                    print(currentDevice.index,"CLI: Sending action to host")
                    CLI_cmd = data['data']
                    print("CLI_cmd:",local_CLI_cmd)
                    print("Sending Repond........")
                    conn.send("Received".encode(FORMAT))
                elif(data['cmd']=="OD"):
                    conn.send("Device Location Received from server".encode(FORMAT))
                    #{'cmd': 'OD', 
                    # 'data': '[{"index": [[9]], "coordination": [[271.0, 367.0], [242.0, 260.0], [325.0, 235.0], [356.0, 351.0]],
                    # "orientation": 255}]'}
                    
                    print(type(data['data']['data']))
                    x = json.loads(data['data']['data'])
                    print("x",x)
                    print(x[0]['coordination'][0]) # Coordination of top left corner
                    
                    
                        
               
                else:
                    conn.send("Not a command".encode(FORMAT))
            else:
                conn.send("Unrecognised communication".encode(FORMAT))
                    
        #lock.release()       
                
            
    conn.close()
    print("Ended connection with ", addr)
        

def start():
    server.listen()
    print(f"[LISTENING] Server is listening on {SERVER}")
    while True:
        conn, addr = server.accept()
        thread = threading.Thread(target=handle_client, args=(conn, addr))
        thread.start()
        print(f"[ACTIVE CONNECTIONS] {threading.activeCount() - 1}")

print("[STARTING] server is starting...")
start()

